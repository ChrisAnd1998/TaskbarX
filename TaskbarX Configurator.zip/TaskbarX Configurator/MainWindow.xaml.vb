﻿Option Strict On

Imports System.IO
Imports System.Net
Imports System.Reflection
Imports System.Runtime.InteropServices
Imports System.Text
Imports System.Windows.Automation
Imports Microsoft.Win32.TaskScheduler

Class MainWindow

    <DllImport("user32.dll", ExactSpelling:=True, CharSet:=CharSet.Auto)>
    Public Shared Function GetParent(ByVal hWnd As IntPtr) As IntPtr
    End Function

    <DllImport("user32.dll", SetLastError:=True)>
    Private Shared Function SetWindowPos(ByVal hWnd As IntPtr, ByVal hWndInsertAfter As IntPtr, ByVal X As Integer, ByVal Y As Integer, ByVal cx As Integer, ByVal cy As Integer, ByVal uFlags As UInt32) As Boolean
    End Function

    <DllImport("user32.dll")>
    Public Shared Function SendMessage(ByVal hWnd As IntPtr, ByVal wMsg As Int32, ByVal wParam As Boolean, ByVal lParam As Int32) As Integer
    End Function

    <DllImport("user32.dll", EntryPoint:="FindWindow", SetLastError:=True, CharSet:=Runtime.InteropServices.CharSet.Auto)>
    Private Shared Function FindWindowByClass(ByVal lpClassName As String, ByVal zero As IntPtr) As IntPtr
    End Function

    Public Shared SWP_NOSIZE As UInt32 = 1
    Public Shared SWP_ASYNCWINDOWPOS As UInt32 = 16384
    Public Shared SWP_NOACTIVATE As UInt32 = 16
    Public Shared SWP_NOSENDCHANGING As UInt32 = 1024
    Public Shared SWP_NOZORDER As UInt32 = 4

    Public Delegate Function CallBack(ByVal hwnd As IntPtr, ByVal lParam As Integer) As Boolean

    Public Declare Function EnumWindows Lib "user32" (ByVal Adress As CallBack, ByVal y As Integer) As Integer
    Public Shared ActiveWindows As New System.Collections.ObjectModel.Collection(Of IntPtr)

    <DllImport("user32.dll", CharSet:=CharSet.Auto)>
    Private Shared Function GetClassName(ByVal hWnd As System.IntPtr, ByVal lpClassName As System.Text.StringBuilder, ByVal nMaxCount As Integer) As Integer
    End Function

    Public Shared Function GetActiveWindows() As ObjectModel.Collection(Of IntPtr)
        windowHandles.Clear()
        EnumWindows(AddressOf Enumerator, 0)
        Return ActiveWindows
    End Function

    Public Shared Function Enumerator(ByVal hwnd As IntPtr, ByVal lParam As Integer) As Boolean
        Dim sClassName As New StringBuilder("", 256)
        Call GetClassName(hwnd, sClassName, 256)
        If sClassName.ToString = "Shell_TrayWnd" Or sClassName.ToString = "Shell_SecondaryTrayWnd" Then
            windowHandles.Add(hwnd)
        End If
        Return True
    End Function

    Public Shared windowHandles As ArrayList = New ArrayList()

    Public Shared Sub RevertToZero()

        If System.AppDomain.CurrentDomain.BaseDirectory.Contains("40210ChrisAndriessen") Then
            Dim processInfo As ProcessStartInfo = New ProcessStartInfo()
            processInfo.WindowStyle = ProcessWindowStyle.Hidden
            processInfo.FileName = "cmd.exe"
            processInfo.Arguments = " /c start shell:AppsFolder\40210ChrisAndriessen.FalconX_y1dazs5f5wq00!TaskbarX " & "-stop"
            Process.Start(processInfo)
        Else

            System.Diagnostics.Process.Start("TaskbarX.exe", "-stop")

        End If

    End Sub

    Private Sub Window_Loaded(ByVal sender As Object, ByVal e As RoutedEventArgs)
        Checkbox10.Visibility = Visibility.Hidden
        ListBox1.SelectedIndex = 0

        ComboBox1.Items.Add("none")
        ComboBox1.Items.Add("linear")
        ComboBox1.Items.Add("expoeaseout")
        ComboBox1.Items.Add("expoeasein")
        ComboBox1.Items.Add("expoeaseinout")
        ComboBox1.Items.Add("expoeaseoutin")
        ComboBox1.Items.Add("circeaseout")
        ComboBox1.Items.Add("circeasein")
        ComboBox1.Items.Add("circeaseinout")
        ComboBox1.Items.Add("circeaseoutin")
        ComboBox1.Items.Add("quadeaseout")
        ComboBox1.Items.Add("quadeasein")
        ComboBox1.Items.Add("quadeaseinout")
        ComboBox1.Items.Add("quadeaseoutin")
        ComboBox1.Items.Add("sineeaseout")
        ComboBox1.Items.Add("sineeasein")
        ComboBox1.Items.Add("sineeaseinout")
        ComboBox1.Items.Add("sineeaseoutin")
        ComboBox1.Items.Add("cubiceaseout")
        ComboBox1.Items.Add("cubiceasein")
        ComboBox1.Items.Add("cubiceaseinout")
        ComboBox1.Items.Add("cubiceaseoutin")
        ComboBox1.Items.Add("quarteaseout")
        ComboBox1.Items.Add("quarteasein")
        ComboBox1.Items.Add("quarteaseinout")
        ComboBox1.Items.Add("quarteaseoutin")
        ComboBox1.Items.Add("quinteaseout")
        ComboBox1.Items.Add("quinteasein")
        ComboBox1.Items.Add("quinteaseinout")
        ComboBox1.Items.Add("quinteaseoutin")
        ComboBox1.Items.Add("elasticeaseout")
        ComboBox1.Items.Add("elasticeasein")
        ComboBox1.Items.Add("elasticeaseinout")
        ComboBox1.Items.Add("elasticeaseoutin")
        ComboBox1.Items.Add("bounceeaseout")
        ComboBox1.Items.Add("bounceeasein")
        ComboBox1.Items.Add("bounceeaseinout")
        ComboBox1.Items.Add("bounceeaseoutin")
        ComboBox1.Items.Add("backeaseout")
        ComboBox1.Items.Add("backeasein")
        ComboBox1.Items.Add("backeaseinout")
        ComboBox1.Items.Add("backeaseoutin")

        ComboBox1.SelectedItem = "cubiceaseinout"

        ComboBox2.Items.Add("none")
        ComboBox2.Items.Add("linear")
        ComboBox2.Items.Add("expoeaseout")
        ComboBox2.Items.Add("expoeasein")
        ComboBox2.Items.Add("expoeaseinout")
        ComboBox2.Items.Add("expoeaseoutin")
        ComboBox2.Items.Add("circeaseout")
        ComboBox2.Items.Add("circeasein")
        ComboBox2.Items.Add("circeaseinout")
        ComboBox2.Items.Add("circeaseoutin")
        ComboBox2.Items.Add("quadeaseout")
        ComboBox2.Items.Add("quadeasein")
        ComboBox2.Items.Add("quadeaseinout")
        ComboBox2.Items.Add("quadeaseoutin")
        ComboBox2.Items.Add("sineeaseout")
        ComboBox2.Items.Add("sineeasein")
        ComboBox2.Items.Add("sineeaseinout")
        ComboBox2.Items.Add("sineeaseoutin")
        ComboBox2.Items.Add("cubiceaseout")
        ComboBox2.Items.Add("cubiceasein")
        ComboBox2.Items.Add("cubiceaseinout")
        ComboBox2.Items.Add("cubiceaseoutin")
        ComboBox2.Items.Add("quarteaseout")
        ComboBox2.Items.Add("quarteasein")
        ComboBox2.Items.Add("quarteaseinout")
        ComboBox2.Items.Add("quarteaseoutin")
        ComboBox2.Items.Add("quinteaseout")
        ComboBox2.Items.Add("quinteasein")
        ComboBox2.Items.Add("quinteaseinout")
        ComboBox2.Items.Add("quinteaseoutin")
        ComboBox2.Items.Add("elasticeaseout")
        ComboBox2.Items.Add("elasticeasein")
        ComboBox2.Items.Add("elasticeaseinout")
        ComboBox2.Items.Add("elasticeaseoutin")
        ComboBox2.Items.Add("bounceeaseout")
        ComboBox2.Items.Add("bounceeasein")
        ComboBox2.Items.Add("bounceeaseinout")
        ComboBox2.Items.Add("bounceeaseoutin")
        ComboBox2.Items.Add("backeaseout")
        ComboBox2.Items.Add("backeasein")
        ComboBox2.Items.Add("backeaseinout")
        ComboBox2.Items.Add("backeaseoutin")

        ComboBox2.SelectedItem = "cubiceaseinout"

        If Not System.AppDomain.CurrentDomain.BaseDirectory.Contains("40210ChrisAndriessen") Then
            Try
                Dim address As String = "https://raw.githubusercontent.com/ChrisAnd1998/FalconX-Center-Taskbar/master/VERSION"
                Dim client As WebClient = New WebClient()
                client.CachePolicy = New System.Net.Cache.RequestCachePolicy(System.Net.Cache.RequestCacheLevel.NoCacheNoStore)
                Dim reader As StreamReader = New StreamReader(client.OpenRead(address))

                Dim latest = reader.ReadToEnd.ToString

                If latest.Contains(Assembly.GetExecutingAssembly().GetName().Version.ToString()) Then
                    vers.Text = "You are up to date."
                Else
                    vers.Text = "Update " & latest.Substring(0, 7) & " is available!"
                End If

                reader.Dispose()
                client.Dispose()
            Catch
            End Try
        Else
            bb.Visibility = Visibility.Hidden
            vers.Visibility = Visibility.Hidden
        End If

        Try

            Using ts As TaskService = New TaskService()

                Dim td = ts.GetTask("TaskbarX")

                Dim cfg As String = Nothing

                If System.AppDomain.CurrentDomain.BaseDirectory.Contains("40210ChrisAndriessen") Then
                    cfg = td.Definition.Actions.ToString.Replace("cmd.exe /c start shell:AppsFolder\40210ChrisAndriessen.FalconX_y1dazs5f5wq00!TaskbarX", "")
                Else
                    cfg = td.Definition.Actions.ToString.Replace(System.AppDomain.CurrentDomain.BaseDirectory & "TaskbarX.exe", "")
                End If

                Dim arguments() As String = cfg.Split(CType(" ", Char()))

                For Each argument In arguments
                    Dim val() As String = Split(argument, "=")
                    Console.WriteLine(val(0))
                    If argument.Contains("-tbs") Then
                        If CInt(val(1)) = 0 Then
                            RadioButton1.IsChecked = True
                        End If
                        If CInt(val(1)) = 1 Then
                            RadioButton2.IsChecked = True
                        End If
                        If CInt(val(1)) = 2 Then
                            RadioButton3.IsChecked = True
                        End If
                        If CInt(val(1)) = 3 Then
                            RadioButton4.IsChecked = True
                        End If
                    End If
                    If argument.Contains("-ptbo") Then
                        NumericUpDown1.Text = val(1)
                    End If
                    If argument.Contains("-stbo") Then
                        NumericUpDown2.Text = val(1)
                    End If
                    If argument.Contains("-cpo") Then
                        If val(1) = "1" Then
                            CheckBox2.IsChecked = True
                        End If
                    End If
                    If argument.Contains("-cso") Then
                        If val(1) = "1" Then
                            CheckBox3.IsChecked = True
                        End If
                    End If
                    If argument.Contains("-as") Then
                        ComboBox1.SelectedItem = val(1)

                    End If
                    If argument.Contains("-asp") Then
                        NumericUpDown4.Text = val(1)
                    End If
                    If argument.Contains("-sr") Then
                        NumericUpDown7.Text = val(1)
                    End If
                    If argument.Contains("-lr") Then
                        NumericUpDown3.Text = val(1)
                    End If
                    If argument.Contains("-cib") Then
                        If val(1) = "1" Then
                            CheckBox1.IsChecked = True
                        End If
                    End If
                    If argument.Contains("-obas") Then
                        ComboBox2.SelectedItem = val(1)
                    End If
                    If argument.Contains("-oblr") Then
                        NumericUpDown5.Text = val(1)
                    End If
                    If argument.Contains("-ftotc") Then
                        If val(1) = "1" Then
                            CheckBox4.IsChecked = True
                        End If
                    End If
                    If argument.Contains("-dtbsowm") Then
                        If val(1) = "1" Then
                            Checkbox10.IsChecked = True
                        End If
                    End If
                    If argument.Contains("-cfsa") Then
                        If val(1) = "1" Then
                            Checkbox9.IsChecked = True
                        End If
                    End If

                Next

                Console.WriteLine(td.Definition.Actions.ToString)

                Dim lg As LogonTrigger = CType(td.Definition.Triggers.Item(0), LogonTrigger)
                Dim times As TimeSpan = lg.Delay

                NumericUpDown6.Value = times.Seconds
            End Using
        Catch ex As Exception
            Console.WriteLine(ex.Message)
        End Try
    End Sub

    Private Sub ListBox_SelectionChanged(sender As Object, e As SelectionChangedEventArgs)

        Dim item = CType(sender, ListBox)
        Dim index = item.SelectedIndex

        TabControl1.SelectedIndex = index

    End Sub

    Private Sub Button_Click(sender As Object, e As RoutedEventArgs)
        Me.Close()
    End Sub

    Public Sub Button_Click_1(sender As Object, e As RoutedEventArgs)

        'Kill every other running instance of FalconX

        Try
            For Each prog As Process In Process.GetProcesses
                If prog.ProcessName = "TaskbarX" Then
                    prog.Kill()
                End If
            Next
        Catch ex As Exception

        End Try

        System.Threading.Thread.Sleep(50)

        Dim t1 As System.Threading.Thread = New System.Threading.Thread(AddressOf RevertToZero)
        t1.Start()

        System.Threading.Thread.Sleep(1000)

        'ResetTaskbarStyle()

        Dim parameters As String

        If RadioButton1.IsChecked = True Then
            parameters = parameters & "-tbs=0 "
        End If
        If RadioButton2.IsChecked = True Then
            parameters = parameters & "-tbs=1 "
        End If
        If RadioButton3.IsChecked = True Then
            parameters = parameters & "-tbs=2 "
        End If
        If RadioButton4.IsChecked = True Then
            parameters = parameters & "-tbs=3 "
        End If

        If Not ComboBox1.SelectedItem Is Nothing Then
            parameters = parameters & "-as=" & ComboBox1.SelectedItem.ToString.ToLower & " "
        End If

        If Not ComboBox2.SelectedItem Is Nothing Then
            parameters = parameters & "-obas=" & ComboBox2.SelectedItem.ToString.ToLower & " "
        End If

        If Not NumericUpDown4.Text = Nothing Then
            parameters = parameters & "-asp=" & NumericUpDown4.Text & " "
        End If

        If Not NumericUpDown1.Text = Nothing Then
            parameters = parameters & "-ptbo=" & NumericUpDown1.Text & " "
        End If
        If Not NumericUpDown2.Text = Nothing Then
            parameters = parameters & "-stbo=" & NumericUpDown2.Text & " "
        End If

        If CheckBox1.IsChecked = True Then
            parameters = parameters & "-cib=1 "
        End If

        If Not NumericUpDown3.Text = Nothing Then
            parameters = parameters & "-lr=" & NumericUpDown3.Text & " "
        End If

        If Not NumericUpDown5.Text = Nothing Then
            parameters = parameters & "-oblr=" & NumericUpDown5.Text & " "
        End If

        If Not NumericUpDown7.Text = Nothing Then
            parameters = parameters & "-sr=" & NumericUpDown7.Text & " "
        End If

        If CheckBox2.IsChecked = True Then
            parameters = parameters & "-cpo=1 "
        End If

        If CheckBox3.IsChecked = True Then
            parameters = parameters & "-cso=1 "
        End If

        If CheckBox4.IsChecked = True Then
            parameters = parameters & "-ftotc=1 "
        End If

        If Checkbox10.IsChecked = True Then
            parameters = parameters & "-dtbsowm=1 "
        End If
        If Checkbox9.IsChecked = True Then
            parameters = parameters & "-cfsa=1 "
        End If

        Try
            Using ts As TaskService = New TaskService()
                ts.RootFolder.DeleteTask("TaskbarX")
            End Using
        Catch ex As Exception
            ' MessageBox.Show(ex.Message)
        End Try

        Try
            Using ts As TaskService = New TaskService()

                Dim td As TaskDefinition = ts.NewTask()
                Dim delay As Integer = CInt(NumericUpDown6.Text)

                td.RegistrationInfo.Description = "Center taskbar icons"

                td.Triggers.Add(New LogonTrigger With {
                    .UserId = System.Security.Principal.WindowsIdentity.GetCurrent().Name,
                    .Delay = TimeSpan.FromSeconds(delay)})

                td.Settings.DisallowStartIfOnBatteries = False
                td.Settings.StopIfGoingOnBatteries = False
                td.Settings.RunOnlyIfIdle = False
                td.Settings.IdleSettings.RestartOnIdle = False
                td.Settings.IdleSettings.StopOnIdleEnd = False
                td.Settings.Hidden = True
                td.Settings.ExecutionTimeLimit = TimeSpan.Zero
                td.RegistrationInfo.Author = "Chris Andriessen"

                If System.AppDomain.CurrentDomain.BaseDirectory.Contains("40210ChrisAndriessen") Then

                    td.Actions.Add(New ExecAction("cmd.exe", "/c start shell:AppsFolder\40210ChrisAndriessen.FalconX_y1dazs5f5wq00!TaskbarX " & parameters, Nothing))

                    Dim processInfo As ProcessStartInfo = New ProcessStartInfo()
                    processInfo.WindowStyle = ProcessWindowStyle.Hidden
                    processInfo.FileName = "cmd.exe"
                    processInfo.Arguments = " /c start shell:AppsFolder\40210ChrisAndriessen.FalconX_y1dazs5f5wq00!TaskbarX " & parameters
                    Process.Start(processInfo)
                Else

                    td.Actions.Add(New ExecAction(System.AppDomain.CurrentDomain.BaseDirectory & "TaskbarX.exe", parameters, Nothing))

                    System.Diagnostics.Process.Start("TaskbarX.exe", parameters)

                End If

                ts.RootFolder.RegisterTaskDefinition("TaskbarX", td)

            End Using
        Catch ex As Exception
            ' MessageBox.Show(ex.Message)
        End Try

    End Sub

    Public Shared WM_DWMCOLORIZATIONCOLORCHANGED As Integer = &H320
    Public Shared WM_DWMCOMPOSITIONCHANGED As Integer = &H31E
    Public Shared WM_THEMECHANGED As Integer = &H31A

    Public Shared Sub RefreshWindowsExplorer()
        Dim CLSID_ShellApplication As Guid = New Guid("13709620-C279-11CE-A49E-444553540000")
        Dim shellApplicationType As Type = Type.GetTypeFromCLSID(CLSID_ShellApplication, True)
        Dim shellApplication As Object = Activator.CreateInstance(shellApplicationType)
        Dim windows As Object = shellApplicationType.InvokeMember("Windows", BindingFlags.InvokeMethod, Nothing, shellApplication, New Object(-1) {})
        Dim windowsType As Type = windows.GetType
        Dim count As Object = windowsType.InvokeMember("Count", BindingFlags.GetProperty, Nothing, windows, Nothing)
        Dim i As Integer = 0
        Do While (i < CType(count, Integer))
            Dim item As Object = windowsType.InvokeMember("Item", BindingFlags.InvokeMethod, Nothing, windows, New Object() {i})
            Dim itemType As Type = item.GetType
            Dim itemName As String = CType(itemType.InvokeMember("Name", BindingFlags.GetProperty, Nothing, item, Nothing), String)
            If (itemName = "Shell_TrayWnd") Then
                itemType.InvokeMember("Refresh", BindingFlags.InvokeMethod, Nothing, item, Nothing)
            End If
            i = (i + 1)
        Loop
    End Sub

    Private Sub Button_Click_2(sender As Object, e As RoutedEventArgs)
        'Kill every other running instance of FalconX

        Try
            For Each prog As Process In Process.GetProcesses
                If prog.ProcessName = "TaskbarX" Then
                    prog.Kill()
                End If
            Next
        Catch
        End Try

        System.Threading.Thread.Sleep(50)

        Dim t1 As System.Threading.Thread = New System.Threading.Thread(AddressOf RevertToZero)
        t1.Start()

        ' ResetTaskbarStyle()
    End Sub

    Private Sub Button_Click_3(sender As Object, e As RoutedEventArgs)
        Try
            Using ts As TaskService = New TaskService()
                ts.RootFolder.DeleteTask("TaskbarX")
            End Using
        Catch ex As Exception
            Console.WriteLine(ex.Message)
        End Try

        MessageBox.Show("Taskschedule Removed!")
    End Sub

    Private Sub NumberValidationTextBox(ByVal sender As Object, ByVal e As TextCompositionEventArgs)

        If Not Char.IsNumber(CChar(e.Text)) Then
            If Not e.Text = "-" Then
                e.Handled = True
            End If
        End If

    End Sub

    Private Sub Button_Click_4(sender As Object, e As RoutedEventArgs)

        Try
            Dim address As String = "https://raw.githubusercontent.com/ChrisAnd1998/FalconX-Center-Taskbar/master/VERSION"
            Dim client As WebClient = New WebClient()
            client.CachePolicy = New System.Net.Cache.RequestCachePolicy(System.Net.Cache.RequestCacheLevel.NoCacheNoStore)
            Dim reader As StreamReader = New StreamReader(client.OpenRead(address))

            Dim latest = reader.ReadToEnd.ToString

            If latest.Contains(Assembly.GetExecutingAssembly().GetName().Version.ToString()) Then
                vers.Text = "You are up to date."
            Else
                vers.Text = "Update " & latest.Substring(0, 7) & " is available!"
                Process.Start("https://chrisandriessen.nl/taskbarx")
            End If

            reader.Dispose()
            client.Dispose()
        Catch
        End Try
    End Sub

    Private Sub Button_Click_5(sender As Object, e As RoutedEventArgs)
        Try

            Using ts As TaskService = New TaskService()

                Dim td = ts.GetTask("TaskbarX")

                Dim cfg As String = Nothing

                If System.AppDomain.CurrentDomain.BaseDirectory.Contains("40210ChrisAndriessen") Then
                    cfg = td.Definition.Actions.ToString.Replace("cmd.exe /c start shell:AppsFolder\40210ChrisAndriessen.FalconX_y1dazs5f5wq00!TaskbarX", "")
                Else
                    cfg = td.Definition.Actions.ToString.Replace(System.AppDomain.CurrentDomain.BaseDirectory & "TaskbarX.exe", "")
                End If

                Dim arguments() As String = cfg.Split(CType(" ", Char()))

                For Each argument In arguments
                    Dim val() As String = Split(argument, "=")
                    Console.WriteLine(val(0))
                    If argument.Contains("-tbs") Then
                        If CInt(val(1)) = 0 Then
                            RadioButton1.IsChecked = True
                        End If
                        If CInt(val(1)) = 1 Then
                            RadioButton2.IsChecked = True
                        End If
                        If CInt(val(1)) = 2 Then
                            RadioButton3.IsChecked = True
                        End If
                        If CInt(val(1)) = 3 Then
                            RadioButton4.IsChecked = True
                        End If
                    End If
                    If argument.Contains("-ptbo") Then
                        NumericUpDown1.Text = val(1)
                    End If
                    If argument.Contains("-stbo") Then
                        NumericUpDown2.Text = val(1)
                    End If
                    If argument.Contains("-cpo") Then
                        If val(1) = "1" Then
                            CheckBox2.IsChecked = True
                        End If
                    End If
                    If argument.Contains("-cso") Then
                        If val(1) = "1" Then
                            CheckBox3.IsChecked = True
                        End If
                    End If
                    If argument.Contains("-as") Then
                        ComboBox1.SelectedItem = val(1)

                    End If
                    If argument.Contains("-asp") Then
                        NumericUpDown4.Text = val(1)
                    End If
                    If argument.Contains("-sr") Then
                        NumericUpDown7.Text = val(1)
                    End If
                    If argument.Contains("-lr") Then
                        NumericUpDown3.Text = val(1)
                    End If
                    If argument.Contains("-cib") Then
                        If val(1) = "1" Then
                            CheckBox1.IsChecked = True
                        End If
                    End If
                    If argument.Contains("-obas") Then
                        ComboBox2.SelectedItem = val(1)
                    End If
                    If argument.Contains("-oblr") Then
                        NumericUpDown5.Text = val(1)
                    End If
                    If argument.Contains("-ftotc") Then
                        If val(1) = "1" Then
                            CheckBox4.IsChecked = True
                        End If
                    End If
                    If argument.Contains("-dtbsowm") Then
                        If val(1) = "1" Then
                            Checkbox10.IsChecked = True
                        End If
                    End If
                    If argument.Contains("-cfsa") Then
                        If val(1) = "1" Then
                            Checkbox9.IsChecked = True
                        End If
                    End If

                Next

                Console.WriteLine(td.Definition.Actions.ToString)

                Dim lg As LogonTrigger = CType(td.Definition.Triggers.Item(0), LogonTrigger)
                Dim times As TimeSpan = lg.Delay

                NumericUpDown6.Value = times.Seconds
            End Using
        Catch
        End Try

    End Sub

    Private Sub Button_Click_6(sender As Object, e As RoutedEventArgs)
        RadioButton1.IsChecked = True
        Checkbox10.IsChecked = False
        ComboBox1.SelectedItem = "cubiceaseinout"
        ComboBox2.SelectedItem = "cubiceaseinout"
        NumericUpDown4.Text = "100"
        NumericUpDown1.Text = "0"
        NumericUpDown2.Text = "0"
        CheckBox1.IsChecked = False
        NumericUpDown6.Text = "3"
        CheckBox2.IsChecked = False
        CheckBox3.IsChecked = False
        CheckBox4.IsChecked = True
        Checkbox9.IsChecked = False
        NumericUpDown3.Text = "400"
        NumericUpDown5.Text = "400"
        NumericUpDown7.Text = "0"
    End Sub

    Private Sub Button_Click_7(sender As Object, e As RoutedEventArgs)

        'Kill every other running instance of FalconX

        Try
            For Each prog As Process In Process.GetProcesses
                If prog.ProcessName = "TaskbarX" Then
                    prog.Kill()
                End If
            Next
        Catch ex As Exception

        End Try

        System.Threading.Thread.Sleep(50)

        Dim t1 As System.Threading.Thread = New System.Threading.Thread(AddressOf RevertToZero)
        t1.Start()

        System.Threading.Thread.Sleep(1000)

        'ResetTaskbarStyle()

        Dim parameters As String

        If RadioButton1.IsChecked = True Then
            parameters = parameters & "-tbs=0 "
        End If
        If RadioButton2.IsChecked = True Then
            parameters = parameters & "-tbs=1 "
        End If
        If RadioButton3.IsChecked = True Then
            parameters = parameters & "-tbs=2 "
        End If
        If RadioButton4.IsChecked = True Then
            parameters = parameters & "-tbs=3 "
        End If

        If Not ComboBox1.SelectedItem Is Nothing Then
            parameters = parameters & "-as=" & ComboBox1.SelectedItem.ToString.ToLower & " "
        End If

        If Not ComboBox2.SelectedItem Is Nothing Then
            parameters = parameters & "-obas=" & ComboBox2.SelectedItem.ToString.ToLower & " "
        End If

        If Not NumericUpDown4.Text = Nothing Then
            parameters = parameters & "-asp=" & NumericUpDown4.Text & " "
        End If

        If Not NumericUpDown1.Text = Nothing Then
            parameters = parameters & "-ptbo=" & NumericUpDown1.Text & " "
        End If
        If Not NumericUpDown2.Text = Nothing Then
            parameters = parameters & "-stbo=" & NumericUpDown2.Text & " "
        End If

        If CheckBox1.IsChecked = True Then
            parameters = parameters & "-cib=1 "
        End If

        If Not NumericUpDown3.Text = Nothing Then
            parameters = parameters & "-lr=" & NumericUpDown3.Text & " "
        End If

        If Not NumericUpDown5.Text = Nothing Then
            parameters = parameters & "-oblr=" & NumericUpDown5.Text & " "
        End If

        If Not NumericUpDown7.Text = Nothing Then
            parameters = parameters & "-sr=" & NumericUpDown7.Text & " "
        End If

        If CheckBox2.IsChecked = True Then
            parameters = parameters & "-cpo=1 "
        End If

        If CheckBox3.IsChecked = True Then
            parameters = parameters & "-cso=1 "
        End If

        If CheckBox4.IsChecked = True Then
            parameters = parameters & "-ftotc=1 "
        End If

        If Checkbox10.IsChecked = True Then
            parameters = parameters & "-dtbsowm=1 "
        End If
        If Checkbox9.IsChecked = True Then
            parameters = parameters & "-cfsa=1 "
        End If


        If System.AppDomain.CurrentDomain.BaseDirectory.Contains("40210ChrisAndriessen") Then
            Dim processInfo As ProcessStartInfo = New ProcessStartInfo()
            processInfo.WindowStyle = ProcessWindowStyle.Hidden
            processInfo.FileName = "cmd.exe"
            processInfo.Arguments = " /c start shell:AppsFolder\40210ChrisAndriessen.FalconX_y1dazs5f5wq00!TaskbarX " & parameters
            Process.Start(processInfo)
        Else
            System.Diagnostics.Process.Start("TaskbarX.exe", parameters)
        End If




    End Sub


End Class